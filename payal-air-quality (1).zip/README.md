# Air Quality Prediction and Classification
This project analyzes air quality data and uses classification models to predict pollution levels.

## Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn
